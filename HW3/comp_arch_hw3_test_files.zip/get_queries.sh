#!/usr/bin/bash

# for i in [1, 20]
#   create the string "dflow_calc tests/opcode${i}.dat tests/example${i}.in "
#   cmd_args=`cat ref_results/example${i}_output | extract_args`

arg_str=""
while read line; do    
    char=${line:10:1}

    if [[ $char == 'h' ]]; then
	cmd_char="p"
    else
	cmd_char="d"
    fi

    num=`echo ${line} | cut -d "(" -f2 | cut -d ")" -f1`
    cmd="${cmd_char}${num}"
    arg_str="$arg_str $cmd"
done

echo $arg_str
