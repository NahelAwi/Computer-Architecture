#! /usr/bin/bash

i=0
for i in {1..20}; do
    tail -n +4 ref_results/example${i}_output > mod_ref_out${i}
    queries=`cat mod_ref_out${i} | ./get_queries.sh`
    ./dflow_calc tests/opcode${i}.dat tests/example${i}.in ${queries} | tail -n +4 > my_example${i}_output
    echo "diffing ${i}"
    diff my_example${i}_output mod_ref_out${i}
    rm my_example${i}_output mod_ref_out${i}
done
